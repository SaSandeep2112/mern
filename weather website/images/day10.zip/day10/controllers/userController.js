const getUser=(req,res)=>{
  res.status(501);
  res.json({
    status:'fail',
    message:"route is not yet impplemented",
  });
  
}

const postUser=(req,res)=>{
  res.status(501);
  res.json({
    status:'fail',
    message:"route is not yet impplemented",
  });
  
}

const putUser=(req,res)=>{
  res.status(501);
  res.json({
    status:'fail',
    message:"route is not yet impplemented",
  });
  
}
const deleteUser=(req,res)=>{
  res.status(501);
  res.json({
    status:'fail',
    message:"route is not yet impplemented",
  });
  
}

module.exports={
  getUser,
  postUser,
  putUser,
  deleteUser
}